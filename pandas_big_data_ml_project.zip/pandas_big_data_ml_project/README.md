# Pandas + ML: Sales Demand Prediction

This project trains a regression model using pandas and scikit-learn on **100,000 rows**.

**Honesty note:** the dataset is synthetic, generated for learning. It is not real customer or company data, and the scores do not establish real-world business performance.

## Files
- `sales_demand_100k.csv`: 100,000-row dataset
- `train_model.py`: end-to-end pandas cleaning, train/test split, model training, evaluation, and saving
- `sales_demand_model.joblib`: trained model from this run
- `sample_predictions.csv`: 20 held-out rows with actual and predicted values
- `metrics.json`: metrics from the completed training run

## Results from the model trained here
- Training rows: 80,000; test rows: 20,000
- MAE: 8.202 units
- RMSE: 10.857 units
- R²: 0.9549
- Fit time in this environment: 0.52 seconds (varies by computer)

## Run on Windows
1. Extract the ZIP.
2. Open PowerShell or Command Prompt in the extracted folder.
3. Optional virtual environment: `python -m venv .venv`
4. Activate it: PowerShell `.\.venv\Scripts\Activate.ps1` or CMD `.venv\Scripts\activate.bat`
5. Install: `python -m pip install -r requirements.txt`
6. Run: `python train_model.py`

## Metrics
- MAE: average absolute prediction error, in units sold.
- RMSE: error metric that penalizes large errors more than MAE.
- R²: relative fit score; interpret it with the dataset and baseline.

## Exercises
1. Change `learning_rate=0.08` to `0.03`. Compare MAE, RMSE, and R².
2. Remove `website_visits` from X. Does performance change?
3. Compare train and test performance to investigate overfitting.
4. This is a randomly split educational dataset. For real forecasting, use a chronological/time-based split to avoid future information leaking into training.
