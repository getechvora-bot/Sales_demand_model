import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Load and inspect data with pandas
df = pd.read_csv("sales_demand_100k.csv", parse_dates=["date"])
print("Dataset shape:", df.shape)
print("\nFirst rows:\n", df.head())
print("\nMissing values:\n", df.isna().sum())
print("\nSummary:\n", df.describe().round(2))

# Basic quality checks
df = df.drop_duplicates().dropna(subset=["units_sold"])
df = df[df["price"] > 0]

# Split features and target
X = df.drop(columns=["date", "units_sold"])
y = df["units_sold"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)
print("\nTrain rows:", len(X_train), "| Test rows:", len(X_test))

# Train regression model
model = HistGradientBoostingRegressor(
    max_iter=100, learning_rate=0.08, max_leaf_nodes=31,
    l2_regularization=1.0, random_state=42
)
model.fit(X_train, y_train)

# Evaluate on held-out test set
pred = model.predict(X_test)
mae = mean_absolute_error(y_test, pred)
rmse = np.sqrt(mean_squared_error(y_test, pred))
r2 = r2_score(y_test, pred)
print(f"\nMAE: {mae:.3f} units")
print(f"RMSE: {rmse:.3f} units")
print(f"R²: {r2:.4f}")

# Save model
joblib.dump(model, "sales_demand_model.joblib")
print("\nSaved model: sales_demand_model.joblib")

# Try a hypothetical new record
new_record = pd.DataFrame([{
    "day_of_week": 2, "month": 10, "is_weekend": 0,
    "price": 45.0, "discount_pct": 10, "ad_spend": 80.0,
    "website_visits": 700, "competitor_price": 47.0, "inventory": 500
}])
print("Example predicted units sold:", round(model.predict(new_record)[0], 1))
