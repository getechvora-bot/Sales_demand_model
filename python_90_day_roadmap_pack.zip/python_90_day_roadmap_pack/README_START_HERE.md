# Python 90-Day Challenge — Start Here

Your existing work is not being replaced. Keep `projects/main.py` as your continuing Study Session Tracker.

## Current position
- Days 1–5: foundations practiced.
- Day 6: lists + functions; mastery check 4/4.
- Next lesson: Day 7.
- Keep daily exercises separate from `projects/main.py`.

## Daily routine (about 2 hours)
1. Learn one concept (20–30 min).
2. Do one guided task (25 min).
3. Solve one task yourself (25 min).
4. Integrate one small feature into the main project only when scheduled (25 min).
5. Run it, record what you learned (10–15 min).

## How our lessons work
I give one small task and hints. You write code. Send your code/output. I review it before giving the next task. Don't skip ahead or copy a complete solution.

## Existing files to preserve
- `projects/main.py` — main Study Session Tracker
- `day-05_Function/calculator.py` — daily practice
- `day_06-lists/study_session_list.py` — daily practice

Copy this pack into your existing project folder carefully. If a file already exists, do not overwrite it.
