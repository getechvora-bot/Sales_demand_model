# 90-Day Python Roadmap

| Days | Focus | Deliverable |
|---|---|---|
| 1–6 | print, variables, input, types, conditions, loops, functions, lists | small scripts; current tracker foundation |
| 7–14 | combine lists/functions, strings, dictionaries, sets, decomposition, debugging | CLI study summary; Phase 1 checkpoint |
| 15–21 | files, CSV, exceptions, modules, JSON, dates | tracker saves and loads data |
| 22–28 | classes, methods, dataclasses, comprehensions, sorting, type hints | Study Tracker v2 |
| 29–42 | algorithms, data structures, Git/GitHub, venv, logging, tests, pytest | tested, version-controlled CLI app |
| 43–56 | NumPy, pandas, cleaning, filtering, groupby, merges, charts, statistics | separate data analysis project |
| 57–70 | HTTP, APIs, validation, FastAPI/Flask, SQL, SQLite, CRUD, tests | small API-backed application |
| 71–82 | AI/LLM concepts, prompting, API or mock, tool calling, embeddings, RAG, evaluation, safety | bounded AI feature prototype |
| 83–90 | user/problem selection, requirements, design, MVP, tests, docs, portfolio | final demo and retrospective |

## Project schedule
- Days 7–14: practice new concepts; add only small, understood features to the existing tracker.
- Days 15–28: add persistence and improve structure.
- Days 29–42: add tests and Git workflow.
- Days 43–56: separate CSV analysis project.
- Days 57–70: API/database project.
- Days 71–82: AI feature, with a local/mock fallback if free API access is unavailable.
- Days 83–90: polish a final portfolio project.

## Milestone gates
Day 14: write a small script without copying.
Day 28: save/load data and explain the structure.
Day 42: use Git and basic automated tests.
Day 56: clean and analyze a dataset.
Day 70: build a basic API-backed app.
Day 82: prototype and evaluate an AI feature.
Day 90: demo a polished project and explain limitations.
