# Progress Tracker

| Day | Status | Evidence | Next action |
|---|---|---|---|
| 1–5 | Practiced | Python basics, conditions, loops, functions and exceptions | Continue current sequence |
| 6 | Quiz passed 4/4 | Lists + functions concepts | Day 7 Task 1 |
| 7 | Not started | — | Complete Day 7 one task at a time |

## After every lesson
- What did I understand?
- What code did I write without help?
- What error did I fix?
- What is still confusing?
- Confidence from 1 to 5:
