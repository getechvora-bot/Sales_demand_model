# Main Project: Study Session Tracker

Do not replace your existing `projects/main.py`.

## Current known features
- validates number of sessions
- collects hours and stores them in a list
- calculates total and average with functions
- displays session hours

## Planned improvements
- Days 7–14: list processing, reusable functions, clearer summaries
- Days 15–21: save/load data using files, CSV, or JSON
- Days 22–28: optional Session class, sorting, cleaner structure
- Days 29–42: tests, Git, logging
- Days 43–56: analyze exported session history with pandas
- Days 57–70: optional API/database version
- Days 71–82: optional AI study summary, evaluated carefully
- Days 83–90: polish and demo

## Safe workflow
1. Save your work before changing it.
2. Add one feature at a time.
3. Run after each change.
4. Test relevant normal and invalid inputs.
5. Do not add advanced features before the course reaches them.
