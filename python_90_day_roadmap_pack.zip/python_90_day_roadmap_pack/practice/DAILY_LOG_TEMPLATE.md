# Daily Learning Log

- Day/date:
- Topic:
- Time spent:
- File edited:
- What I wrote myself:
- Error I fixed:
- What I understand now:
- What is confusing:
- Output/test evidence:
- Confidence (1–5):
