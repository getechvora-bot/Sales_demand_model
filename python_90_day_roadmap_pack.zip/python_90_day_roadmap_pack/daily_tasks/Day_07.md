# Day 7 — Lists + Functions Together

## Task 1 only
Create `day-07-practice/study_tracker.py`. In it, create a list named `study_hours` containing these session durations: 2, 3, 1.5, 2.5. Print the list.

Expected output: `[2, 3, 1.5, 2.5]`

Hints: use square brackets `[]`, commas between values, and `print()`.

Stop after Task 1. Run the file and send me your code and terminal output. I will review it before giving Task 2.

## Project connection
Do not replace `projects/main.py`. This file is a separate daily exercise.
