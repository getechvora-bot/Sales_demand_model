# Day 77 — Tiny retrieval prototype

## Goal
Understand and practice **Tiny retrieval prototype**.

## How to start
Before coding, write down: (1) what problem this concept solves, (2) the expected input, and (3) the expected output.

## Session plan
1. Short explanation and example.
2. One guided task with hints.
3. One similar task you solve independently.
4. Add a small feature to the main project only if it matches this phase; otherwise use a separate practice file.
5. Run the code and record what you learned.

## Mentor rule
Ask the assistant for the first small task. Do not ask for or copy a complete solution. Send your code and terminal output for review before moving on.

## Project
Follow `roadmap/PROJECT_PLAN.md`. Keep your existing `projects/main.py`; do not rewrite it from scratch.
